/*** Variáveis main ***/

//Variáveis Financiamento

var montante;
var entrada;
var prazo;
var emprestimo1;
var emprestimo2;
var emprestimo3;
var prestacao1;
var prestacao2;
var prestacao3;
var spread1;
var spread2;
var spread3;
var juro1;
var juro2;
var juro3;
var montantettl1 = document.querySelector(".montantettl1");
var entradainicial1 = document.querySelector(".entrada1");
var montantettl2 = document.querySelector(".montantettl2");
var entradainicial2 = document.querySelector(".entrada2");
var montantettl3 = document.querySelector(".montantettl3");
var entradainicial3 = document.querySelector(".entrada3");
var emprestimomill = document.querySelector(".emprestimo1");
var emprestimostd = document.querySelector(".emprestimo2");
var emprestimobpi = document.querySelector(".emprestimo3");
var spreadmill = document.querySelector(".spread1");
var spreadstd = document.querySelector(".spread2");
var spreadbpi = document.querySelector(".spread3");
var juromill = document.querySelector(".juro1");
var jurostd = document.querySelector(".juro2");
var jurobpi = document.querySelector(".juro3");
var prestacaomill = document.querySelector(".prestacao1");
var prestacaostd = document.querySelector(".prestacao2");
var prestacaobpi = document.querySelector(".prestacao3");

//Variáveis ProgressBar
var item1 = document.getElementById("item-1");
var item2 = document.getElementById("item-2");
var item3 = document.getElementById("item-3");
var item4 = document.getElementById("item-4");

//Variáveis Tipo
var tipo;
var tipologia1 = document.querySelector(".tipologia1");
var tipologia2 = document.querySelector(".tipologia2");
var tipologia3 = document.querySelector(".tipologia3");

//Variáveis Area
var area;
var areadisplay1 = document.querySelector(".area1");
var areadisplay2 = document.querySelector(".area2");
var areadisplay3 = document.querySelector(".area3");

//Variável Idade
var c1;
var idade1 = document.querySelector(".idade1");
var idade2 = document.querySelector(".idade2");
var idade3 = document.querySelector(".idade3");

//Variáveis Garagem
var c2;
var cc2;
var garagem1 = document.querySelector(".garagem1");
var garagem2 = document.querySelector(".garagem2");
var garagem3 = document.querySelector(".garagem3");

//Variáveis Transporte
var c3;
var cc3;
var transportes1 = document.querySelector(".transportes1");
var transportes2 = document.querySelector(".transportes2");
var transportes3 = document.querySelector(".transportes3");

var v1 = document.getElementById("valorcasa1");
var v2 = document.getElementById("valorcasa2");
var v3 = document.getElementById("valorcasa3");
var div1 = document.querySelector(".um");
var div2 = document.querySelector(".dois");
var div3 = document.querySelector(".tres");
var div4 = document.querySelector(".quatro");
var divcenarios = document.querySelector(".cenarios");
var fbtn = document.querySelector(".finance");
var continuar = document.querySelector(".continue");
var retorno = document.querySelector(".goback");
var start = document.querySelector(".valorcasa");
var returnbtn = document.querySelector(".retorno");
var financebtn = document.querySelector(".financiamento");

//Variáveis ValoresCasa
var coimbra = document.getElementById("caixacoimbra");
var lisboa = document.getElementById("caixalisboa");
var porto = document.getElementById("caixaporto");
var financecoimbra = document.getElementById("valorcoimbra");
var financelisboa = document.getElementById("valorlisboa");
var financeporto = document.getElementById("valorporto");

//Variáveis Favoritos
var fav1 = document.querySelector(".fav-1");
var fav2 = document.querySelector(".fav-2");
var fav3 = document.querySelector(".fav-3");
var fav4 = document.querySelector(".fav-4");
var fav5 = document.querySelector(".fav-5");
var fav6 = document.querySelector(".fav-6");
var fav7 = document.querySelector(".fav-7");
var fav8 = document.querySelector(".fav-8");
var fav9 = document.querySelector(".fav-9");
var fav10 = document.querySelector(".fav-10");
var fav11 = document.querySelector(".fav-11");
var fav12 = document.querySelector(".fav-12");

//Variáveis Desvalorização
var z1 = 1200;
var z2 = 2000;
var z3 = 2500;
var v1;
var v2;
var v3;
var c;

//Variáveis Util
var cont = 1;
var verificar;
var contador = 0;
var contverify = 0;

/*** Funções ***/

//Função que calcula o valor das casas em 3 zonas diferentes consoante o coeficiente de desvalorizacao
function desvalor() {
  if (c1 <= 5) {
    c1 = 1;
  } else if (5 < c1 && c1 < 10) {
    c1 = 0.95;
  } else if (c1 > 10) {
    c1 = 0.9;
  }

  if (c2 == true) {
    c2 = 1;
  } else {
    c2 = 0.95;
  }

  if (c3 == true) {
    c3 = 1;
  } else {
    c3 = 0.9;
  }

  c = c1 * c2 * c3;

  return c;
}

//Função ProgressBar
function progress1() {
  item1.classList.add("ativo");
  item2.classList.remove("ativo");
}
function progress2() {
  item2.classList.add("ativo");
  item1.classList.remove("ativo");
  item3.classList.remove("ativo");
}
function progress3() {
  item3.classList.add("ativo");
  item2.classList.remove("ativo");
  item4.classList.remove("ativo");
}
function progress4() {
  item4.classList.add("ativo");
  item3.classList.remove("ativo");
}

//Função Verificar preenchimento
function verificarinput() {
  tipo = document.getElementById("tipo").value;
  area = document.getElementById("area").value;
  c1 = document.getElementById("idd").value;
  c2 = document.getElementById("simgaragem").checked;
  cc2 = document.getElementById("naogaragem").checked;
  c3 = document.getElementById("simtransp").checked;
  cc3 = document.getElementById("naotransp").checked;
  if (c2 != cc2 && c3 != cc3 && tipo && area && c1) {
    verificar = 1;
  } else {
    verificar = 0;
  }
  return verificar;
}

//Função Verificar preenchimento financiamento
function verificarfinance() {
  montante = document.getElementById("montante").value;
  prazo = document.getElementById("prazo").value;
  entrada = document.getElementById("entrada").value;
  if (montante && prazo && entrada) {
    verificar = 1;
  } else {
    verificar = 0;
  }
  return verificar;
}

//Função Mover Valores
function movervalor() {
  tipologia1.insertAdjacentHTML("beforeend", tipo);
  tipologia2.insertAdjacentHTML("beforeend", tipo);
  tipologia3.insertAdjacentHTML("beforeend", tipo);
  areadisplay1.insertAdjacentHTML("beforeend", area);
  areadisplay2.insertAdjacentHTML("beforeend", area);
  areadisplay3.insertAdjacentHTML("beforeend", area);
  areadisplay1.insertAdjacentHTML("beforeend", "m<sup>2</sup>");
  areadisplay2.insertAdjacentHTML("beforeend", "m<sup>2</sup>");
  areadisplay3.insertAdjacentHTML("beforeend", "m<sup>2</sup>");
  idade1.insertAdjacentHTML("beforeend", c1);
  idade2.insertAdjacentHTML("beforeend", c1);
  idade3.insertAdjacentHTML("beforeend", c1);
}

//Função Garagem/Transporte Sim/Não
function garagemSNtransporteSN() {
  if (c2 == true) {
    garagem1.insertAdjacentHTML("beforeend", "Sim");
    garagem2.insertAdjacentHTML("beforeend", "Sim");
    garagem3.insertAdjacentHTML("beforeend", "Sim");
  } else {
    garagem1.insertAdjacentHTML("beforeend", "Não");
    garagem2.insertAdjacentHTML("beforeend", "Não");
    garagem3.insertAdjacentHTML("beforeend", "Não");
  }
  if (c3 == true) {
    transportes1.insertAdjacentHTML("beforeend", "Sim");
    transportes2.insertAdjacentHTML("beforeend", "Sim");
    transportes3.insertAdjacentHTML("beforeend", "Sim");
  } else {
    transportes1.insertAdjacentHTML("beforeend", "Não");
    transportes2.insertAdjacentHTML("beforeend", "Não");
    transportes3.insertAdjacentHTML("beforeend", "Não");
  }
}

//Função valores de casa em Coimbra/Lisboa/Porto
function valorescasa() {
  c = desvalor(c1, c2, c3);
  v1.insertAdjacentHTML(
    "afterbegin",
    (area * z1 * c).toLocaleString(undefined)
  );
  v2.insertAdjacentHTML(
    "afterbegin",
    (area * z2 * c).toLocaleString(undefined)
  );
  v3.insertAdjacentHTML(
    "afterbegin",
    (area * z3 * c).toLocaleString(undefined)
  );
}

//Função Reset Informação
function resetinformacao() {
  tipologia1.innerHTML = "Tipologia: ";
  areadisplay1.innerHTML = "Área: ";
  idade1.innerHTML = "Idade: ";
  garagem1.innerHTML = "Garagem: ";
  transportes1.innerHTML = "Transportes: ";
  tipologia2.innerHTML = "Tipologia: ";
  areadisplay2.innerHTML = "Área: ";
  idade2.innerHTML = "Idade: ";
  garagem2.innerHTML = "Garagem: ";
  transportes2.innerHTML = "Transportes: ";
  tipologia3.innerHTML = "Tipologia: ";
  areadisplay3.innerHTML = "Área: ";
  idade3.innerHTML = "Idade: ";
  garagem3.innerHTML = "Garagem: ";
  transportes3.innerHTML = "Transportes: ";
  v1.innerHTML = "€";
  v2.innerHTML = "€";
  v3.innerHTML = "€";
}

//Funções Continuar/Contador++
start.addEventListener("click", function () {
  cont++;
  div1.style.display = "none";
  div2.style.display = "block";
  continuar.style.display = "inline";
  retorno.style.display = "inline";
  progress2();
});

continuar.addEventListener("click", function () {
  if (cont == 2 || cont == 3) {
    cont++;
  }
  if (cont == 3) {
    verificar = verificarinput();
    if (verificar == 1) {
      movervalor();
      garagemSNtransporteSN();
      valorescasa();
      progress3();
      div2.style.display = "none";
      div3.style.display = "block";
    } else {
      cont--;
      alert("Falta Informação ou erro no preenchimento");
    }
  } else if (cont == 4) {
    progress4();
    div3.style.display = "none";
    div4.style.display = "block";
    continuar.style.display = "none";
    fbtn.style.display = "block";
  }
});

//Função Retorno/Contador--
retorno.addEventListener("click", function () {
  if (cont == 4 || cont == 3 || cont == 2) {
    cont--;
  }
  if (cont == 1) {
    progress1();
    div1.style.display = "block";
    div2.style.display = "none";
    continuar.style.display = "none";
    retorno.style.display = "none";
    fbtn.style.display = "none";
  } else if (cont == 2) {
    resetinformacao();
    progress2();
    div2.style.display = "block";
    div3.style.display = "none";
    continuar.style.display = "block";
    fbtn.style.display = "none";
  } else if (cont == 3) {
    progress3();
    div3.style.display = "block";
    div4.style.display = "none";
    continuar.style.display = "block";
    fbtn.style.display = "none";
  }
});

//Função Financiamento/Contador Ímpar
financebtn.addEventListener("click", function () {
  contador++;

  if (contador % 2 == 0) {
    divcenarios.style.display = "none";
    resetfinance();
    financebtn.classList.add("financiamento");
    financebtn.classList.remove("financiamento-ativo");
  } else if (contador % 2 != 0 && contador >= 3) {
    verificar = verificarfinance();
    if (verificar == 1) {
      divcenarios.style.display = "block";
      financebtn.classList.remove("financiamento");
      financebtn.classList.add("financiamento-ativo");
      verify();
      moverfinance();
    } else {
      contador--;
      alert("Falta Informação ou erro no preenchimento");
    }
  } else if (contador % 2 != 0) {
    verificar = verificarfinance();
    if (verificar == 1) {
      divcenarios.style.display = "block";
      financebtn.classList.remove("financiamento");
      financebtn.classList.add("financiamento-ativo");
      verify();
      moverfinance();
    } else {
      contador--;
      alert("Falta Informação ou erro no preenchimento");
    }
  }
});

//Função para verificar os valores de financiamento
function verify() {
  contverify++;
  montante = document.getElementById("montante").value;
  prazo = document.getElementById("prazo").value;
  entrada = document.getElementById("entrada").value;
  if (contverify == 1) {
    spread1 = geradorspread1();
    spread2 = geradorspread2();
    spread3 = geradorspread3();
  }
  juro1 = 0.5 + spread1;
  juro2 = 0.5 + spread2;
  juro3 = 0.5 + spread3;

  juro1 = Math.round(juro1 * 100) / 100;
  juro2 = Math.round(juro2 * 100) / 100;
  juro3 = Math.round(juro3 * 100) / 100;

  emprestimo1 = (montante - entrada) * (1 + juro1 / 100);
  emprestimo2 = (montante - entrada) * (1 + juro2 / 100);
  emprestimo3 = (montante - entrada) * (1 + juro3 / 100);

  emprestimo1 = Math.round(emprestimo1 * 100) / 100;
  emprestimo2 = Math.round(emprestimo2 * 100) / 100;
  emprestimo3 = Math.round(emprestimo3 * 100) / 100;

  prestacao1 = emprestimo1 / (prazo * 12);
  prestacao2 = emprestimo2 / (prazo * 12);
  prestacao3 = emprestimo3 / (prazo * 12);

  prestacao1 = Math.round(prestacao1 * 100) / 100;
  prestacao2 = Math.round(prestacao2 * 100) / 100;
  prestacao3 = Math.round(prestacao3 * 100) / 100;

  montante += " €";
  entrada += " €";
  prazo += " €";
}

//Função para mover os valores do financiamento
function moverfinance() {
  montantettl1.insertAdjacentHTML("beforeend", montante);
  entradainicial1.insertAdjacentHTML("beforeend", entrada);
  montantettl2.insertAdjacentHTML("beforeend", montante);
  entradainicial2.insertAdjacentHTML("beforeend", entrada);
  montantettl3.insertAdjacentHTML("beforeend", montante);
  entradainicial3.insertAdjacentHTML("beforeend", entrada);
  emprestimomill.insertAdjacentHTML(
    "beforeend",
    emprestimo1.toLocaleString("pt-PT", { style: "currency", currency: "EUR" })
  );
  emprestimostd.insertAdjacentHTML(
    "beforeend",
    emprestimo2.toLocaleString("pt-PT", { style: "currency", currency: "EUR" })
  );
  emprestimobpi.insertAdjacentHTML(
    "beforeend",
    emprestimo3.toLocaleString("pt-PT", { style: "currency", currency: "EUR" })
  );
  spreadmill.insertAdjacentHTML("beforeend", spread1);
  spreadstd.insertAdjacentHTML("beforeend", spread2);
  spreadbpi.insertAdjacentHTML("beforeend", spread3);
  juromill.insertAdjacentHTML("beforeend", juro1);
  jurostd.insertAdjacentHTML("beforeend", juro2);
  jurobpi.insertAdjacentHTML("beforeend", juro3);
  prestacaomill.insertAdjacentHTML(
    "beforeend",
    prestacao1.toLocaleString("pt-PT", { style: "currency", currency: "EUR" })
  );
  prestacaostd.insertAdjacentHTML(
    "beforeend",
    prestacao2.toLocaleString("pt-PT", { style: "currency", currency: "EUR" })
  );
  prestacaobpi.insertAdjacentHTML(
    "beforeend",
    prestacao3.toLocaleString("pt-PT", { style: "currency", currency: "EUR" })
  );
}

//Função para fazer reset à informação do financiamento
function resetfinance() {
  montantettl1.innerHTML = "Montante Total: ";
  montantettl2.innerHTML = "Montante Total: ";
  montantettl3.innerHTML = "Montante Total: ";
  entradainicial1.innerHTML = "Entrada Inicial: ";
  entradainicial2.innerHTML = "Entrada Inicial: ";
  entradainicial3.innerHTML = "Entrada Inicial: ";
  emprestimomill.innerHTML = "Valor do Empréstimo: ";
  emprestimostd.innerHTML = "Valor do Empréstimo: ";
  emprestimobpi.innerHTML = "Valor do Empréstimo: ";
  spreadmill.innerHTML = "Spread: ";
  spreadstd.innerHTML = "Spread: ";
  spreadbpi.innerHTML = "Spread: ";
  juromill.innerHTML = "Taxa de Juro Global: ";
  jurostd.innerHTML = "Taxa de Juro Global: ";
  jurobpi.innerHTML = "Taxa de Juro Global: ";
  prestacaomill.innerHTML = "Prestação Mensal: ";
  prestacaostd.innerHTML = "Prestação Mensal: ";
  prestacaobpi.innerHTML = "Prestação Mensal: ";
}

//Função para gerar 3 juros diferentes aleatoriamente
function geradorspread1() {
  var precision = 100;
  var spread1 =
    Math.floor(
      Math.random() * (5 * precision - 1 * precision) + 1 * precision
    ) /
    (1 * precision);

  return spread1;
}

function geradorspread2() {
  var precision = 100;
  var spread2 =
    Math.floor(
      Math.random() * (5 * precision - 1 * precision) + 1 * precision
    ) /
    (1 * precision);

  return spread2;
}

function geradorspread3() {
  var precision = 100;
  var spread3 =
    Math.floor(
      Math.random() * (5 * precision - 1 * precision) + 1 * precision
    ) /
    (1 * precision);

  return spread3;
}

//Função Menu Dropdown
function dropdown() {
  document.getElementById("arrowdropdown").classList.toggle("show");
}

window.onclick = function (event) {
  if (!event.target.matches(".dropbtn")) {
    var dropdowns = document.getElementsByClassName("dropdown-content");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains("show")) {
        openDropdown.classList.remove("show");
      }
    }
  }
};

//Funcão scrolltoTop
returnbtn.addEventListener("click", function () {
  window.scrollTo({
    top: 0,
    left: 0,
    behavior: "smooth",
  });
});

//Funções favoritos
fav1.addEventListener("click", function () {
  fav1.style.display = "none";
  fav2.style.display = "block";
});

fav2.addEventListener("click", function () {
  fav1.style.display = "block";
  fav2.style.display = "none";
});

fav3.addEventListener("click", function () {
  fav3.style.display = "none";
  fav4.style.display = "block";
});

fav4.addEventListener("click", function () {
  fav3.style.display = "block";
  fav4.style.display = "none";
});

fav5.addEventListener("click", function () {
  fav5.style.display = "none";
  fav6.style.display = "block";
});

fav6.addEventListener("click", function () {
  fav5.style.display = "block";
  fav6.style.display = "none";
});

fav7.addEventListener("click", function () {
  fav7.style.display = "none";
  fav8.style.display = "block";
});

fav8.addEventListener("click", function () {
  fav7.style.display = "block";
  fav8.style.display = "none";
});

fav9.addEventListener("click", function () {
  fav9.style.display = "none";
  fav10.style.display = "block";
});

fav10.addEventListener("click", function () {
  fav9.style.display = "block";
  fav10.style.display = "none";
});

fav11.addEventListener("click", function () {
  fav11.style.display = "none";
  fav12.style.display = "block";
});

fav12.addEventListener("click", function () {
  fav11.style.display = "block";
  fav12.style.display = "none";
});

//Funções tamanho display de valores casa
coimbra.addEventListener("mouseover", function () {
  financecoimbra.style.display = "block";
  coimbra.style.height = "auto";
  lisboa.style.height = "65px";
  porto.style.height = "65px";
});
coimbra.addEventListener("mouseout", function () {
  financecoimbra.style.display = "none";
  coimbra.style.height = "65px";
});

lisboa.addEventListener("mouseover", function () {
  financelisboa.style.display = "block";
  coimbra.style.height = "65px";
  lisboa.style.height = "auto";
  porto.style.height = "65px";
});
lisboa.addEventListener("mouseout", function () {
  financelisboa.style.display = "none";
  lisboa.style.height = "65px";
});

porto.addEventListener("mouseover", function () {
  financeporto.style.display = "block";
  coimbra.style.height = "65px";
  lisboa.style.height = "65px";
  porto.style.height = "auto";
});
porto.addEventListener("mouseout", function () {
  financeporto.style.display = "none";
  porto.style.height = "65px";
});
